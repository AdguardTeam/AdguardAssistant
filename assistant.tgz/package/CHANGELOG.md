# AdGuard Assistant Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog], and this project adheres to [Semantic Versioning].

[Keep a Changelog]: https://keepachangelog.com/en/1.0.0/
[Semantic Versioning]: https://semver.org/spec/v2.0.0.html

## [4.4.3] - 2026-02-24

### Added

- Support for changing the icon color based on the browser theme (light/dark) [#439].

### Changed

- Updated packages to latest stable versions [#275].

### Fixed

- Shadow at the bottom of the element picker is displayed as a white strip in Safari/Chrome dark mode [#442].

[#275]: https://github.com/AdguardTeam/AdguardAssistant/issues/275
[#442]: https://github.com/AdguardTeam/AdguardAssistant/issues/442
[#439]: https://github.com/AdguardTeam/AdguardAssistant/issues/439

[4.4.1]: https://github.com/AdguardTeam/AdguardAssistant/compare/v4.3.77...v4.4.3

## [4.3.77] - 2025-09-23

### Fixed

- AdGuard Assistant icon doesn't appear on YouTube and Google sites [#438].

[#438]: https://github.com/AdguardTeam/AdguardAssistant/issues/438
[4.3.77]: https://github.com/AdguardTeam/AdguardAssistant/compare/v4.3.75...v4.3.77

## [4.3.75] - 2025-07-29

### Fixed

- Fix broken settings screen [#433].

[#433]: https://github.com/AdguardTeam/AdguardAssistant/issues/433
[4.3.75]: https://github.com/AdguardTeam/AdguardAssistant/compare/v4.3.74...v4.3.75

## [4.3.74] - 2025-06-30

### Added

- Support of Bulgarian, Catalan, Macedonian and Thai locales.

### Changed

- Updated UI of element selector menu to match with other projects.

### Fixed

- Issue with slider dragging does not work properly on touch devices.

[4.3.74]: https://github.com/AdguardTeam/AdguardAssistant/compare/v4.3.70...v4.3.74

## [4.3.70] - 2023-06-01

### Added

- `self` type build [AdguardForMac#1246].

[4.3.70]: https://github.com/AdguardTeam/AdguardAssistant/compare/v4.3.68...v4.3.70
[AdguardForMac#1246]: https://github.com/AdguardTeam/AdguardForMac/issues/1246
