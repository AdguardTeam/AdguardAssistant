### Certificates for Safari Extension

1. You will need a Developer Certificate as described in the [Safari Extension Development Guide](https://developer.apple.com/library/safari/documentation/Tools/Conceptual/SafariExtensionGuide/UsingExtensionBuilder/UsingExtensionBuilder.html)
1. Once you have the Developer Certificate installed in your
   keychain, you will need to export it.
   1. Go to the 'Certificates' section of the 'Keychain Access'
      application, command-click on the 'Safari Developer: ...'
      certificate and select the 'Export' option.
   2. Save the certificate using the .p12 format.
   3. Extract the public and private keys from the resulting
      .p12 file using openssl:

    ````
    # export public certificate
    openssl pkcs12 -in safari-certs.p12 -nokeys -out cert.pem

    # export private key (note the 'nodes' option means that it will be unencrypted)
    openssl pkcs12 -nodes -in safari-certs.p12 -nocerts -out privatekey.pem
    ````
3. Export the intermediate certificate and root certificates used
   to sign your developer certificate from Keychain Access.

   These are the 'Apple Worldwide Developer Relations Certification Authority' (usually in your login keychain) and the 'Apple Root CA' certificate (usually in the 'System Roots' section).
   (These are named `apple-intermediate.pem` and `apple-root.pem`
    in the following instructions).

   In the export options dialog, select the Privacy Enhanced Mail (PEM) format.
4. If you have only a .cer certificate you can convert it to .pem by command
    ```
    openssl x509 -inform der -in certificate.cer -out certificate.pem
    ```
