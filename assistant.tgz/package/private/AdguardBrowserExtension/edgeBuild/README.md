## Edge Extension Packing

#### Downloads and install Windows 10 SDK

https://developer.microsoft.com/en-us/windows/downloads/windows-10-sdk

#### Update path to the kit in the buils.sh script
$sdk="C:\Program Files (x86)\Windows Kits\10\bin\10.0.17134.0\x64"

#### Create certificates

Read:
https://msdn.microsoft.com/windows/uwp/packaging/create-certificate-package-signing

TL;DR
Run command in Powershell as Administrator

##### Release Cert
```
New-SelfSignedCertificate -Type Custom -Subject "CN=E412EBA6-7C15-4234-8CD0-656E0121592C" -KeyUsage DigitalSignature -FriendlyName Adguard -CertStoreLocation "Cert:\LocalMachine\My"
```
```
$pwd = ConvertTo-SecureString -String OpJ8xpMyAx -Force -AsPlainText
```
Replace <Thumbprint> with value from first step 
```
Export-PfxCertificate -cert "Cert:\LocalMachine\My\<Thumbprint>" -FilePath CertRelease.pfx -Password $pwd
```

##### Beta Cert
```
New-SelfSignedCertificate -Type Custom -Subject "CN=E412EBA6-7C15-4234-8CD0-656E0121592C" -KeyUsage DigitalSignature -FriendlyName Adguard -CertStoreLocation "Cert:\LocalMachine\My"
```
```
$pwd = ConvertTo-SecureString -String mz7D5nu69J -Force -AsPlainText
```
Replace <Thumbprint> with value from first step 
```
Export-PfxCertificate -cert "Cert:\LocalMachine\My\<Thumbprint>" -FilePath CertBeta.pfx -Password $pwd
```

#### Install certificates

Install certificates into `Local Machine` -> insert password from previous -> Place certificate in Trusted Root Certification Authorities

#### Pack extensions:

##### Release Build

Check if version of the Windows SDK is the same as in the build.ps1 file

1. Copy Build/Release/edge-${version} to EdgeBuild folder

2. Run command in PowerShell
```
.\build.ps1 edge-release-${version} AdguardAdblocker ${version} CertRelease.pfx OpJ8xpMyAx
```

##### Beta Build

1. Copy Build/Beta/edge-${version} to EdgeBuild folder

2. Run command in PowerShell
```
.\build.ps1 edge-beta-${version} AdguardAdblockerBeta ${version} CertBeta.pfx mz7D5nu69J
```

*Note: If scripts don't run due to Restricted Execution Policy, execute following command in the PowerShell:*  
```
Set-ExecutionPolicy Unrestricted
```

