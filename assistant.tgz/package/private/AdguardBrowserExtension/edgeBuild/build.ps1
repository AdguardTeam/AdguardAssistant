$src=$args[0]
$dst=$args[1]
$version=$args[2]
$cert=$args[3]
$pwd=$args[4]
$sdk="C:\Program Files (x86)\Windows Kits\10\bin\10.0.17134.0\x64"

echo "Remove $dst-$version folder if exists"
Remove-Item $dst-$version -Recurse -ErrorAction Ignore

echo "Creating $dst-$version file"
Copy-Item "$dst" "$dst-$version" -Recurse -Force

echo "Copy sources to $dst-$version\Extension\ folder"
Copy-Item "$src" "$dst-$version\Extension" -Recurse -Force

echo "Updating version in $dst-$version\appxmanifest.xml to $version"
(Get-Content $dst-$version\appxmanifest.xml | out-string).Replace("VERSION","$version") | Set-Content $dst-$version\appxmanifest.xml

echo "Creating resources.pri file"
& "$sdk\makepri.exe" new /pr "$dst-$version\" /cf "$dst-$version\priconfig.xml" /mn "$dst-$version\appxmanifest.xml" /of "$dst-$version\resources.pri" /o

echo "Creating .appx file"
& "$sdk\makeappx.exe" pack /h SHA256 /d "$dst-$version\" /p "$dst-$version.appx"

echo "Sign .appx file"
& "$sdk\signtool.exe" sign /fd SHA256 /a /f $cert /p $pwd "$dst-$version.appx"
