# Adguard extensions repository

In this repository we store extensions certificates and some useful scripts.
This content should be cloned to extension directory:

##### Browser Extension:
```
    git clone https://github.com/AdguardTeam/AdguardBrowserExtension.git
    cd AdguardBrowserExtension/
    git clone ssh://git@bit.adguard.com:7999/extensions/private.git
```

### Contents:
- **/AdguardBrowserAssistant/certificate-beta.pem** - AdguardBrowserAssistant Chromium Beta build certificate
- **/AdguardBrowserAssistant/certificate-release.pem** - AdguardBrowserAssistant Chromium Release build certificate
- **/AdguardBrowserAssistant/mozilla_credentials.json** - AdguardBrowserAssistant Mozilla build credentials

- **/AdguardBrowserExtension/certificate.pem** - AdguardBrowserExtension Chromium Beta build certificate
- **/AdguardBrowserExtension/mozilla_credentials.json** - AdguardBrowserExtension Mozilla build credentials
- **/AdguardBrowserExtension/safari_certs/** - AdguardBrowserExtension Safari build certificates
- **/AdguardBrowserExtension/edgeBuild/** - AdguardBrowserExtension Edge build certificates and scripts

- **/AdguardExtra/certificate.pem** - AdguardExtra Chromium build certificate
- **/AdguardExtra/mozilla_credentials.json** - AdguardExtra Mozilla build credentials

- **/AdguardVPN/certificate-beta.pem** - Adguard VPN extension Chromium beta build certificate
- **/AdguardVPN/certificate-release.pem** - Adguard VPN extension Chromium release build certificate
- **/AdguardVPN/mozilla_credentials.json** - Adguard VPN extension credentials for Mozilla

- **/cryptor/** - Script for encrypting and decrypting files with AES 

### Encryption
Mozilla's credentials should be kept encrypted with cryptor script (look `./cryptor/README.md` directory) in order to prevent accidental uploading to the AMO (addons.mozilla.org).

In the extensions' directory for building tasks you should use cryptor script (`./cryptor/README.md`) in order to decrypt credentials (look API section). SECRET_KEY should be provided via env variables.
```
SECRET_KEY=1231232 yarn run build-script
```
