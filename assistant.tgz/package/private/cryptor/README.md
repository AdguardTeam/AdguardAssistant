# Cryptor

Package for encrypting and decrypting of files with AES cipher.

Is build on the base of [crypto-js](https://github.com/brix/crypto-js) library.

As we use a passphrase, then it generates a 256-bit key.

## Usage

### Build
If you've made some changes in the source code, run
```
yarn build
```
in order to update dist and commit changes.

### CLI

#### Setup
- `yarn install` - installs external dependencies
- `yarn link` - links package, so you can use it from cli

#### Encrypt file

`cryptor encrypt <input> [output] -p <password>`

e.g.

- `cryptor encrypt mozilla_credentials.json -p <SECRET_KEY>` - this command would encrypt content of `mozilla_credentials.json`

- `cryptor encrypt mozilla_credentials.json encrypted.txt -p <SECRET_KEY>` - this command would encrypt content of `mozilla_credentials.json` and save it in the `encrypted.txt` file

#### Decrypt file

`cryptor encrypt <input> [output] -p <password>`

e.g.

- `cryptor decrypt mozilla_credentials.json -p <SECRET_KEY>` - this command would decrypt content of `mozilla_credentials.json` and save it in the same file

- `cryptor decrypt mozilla_credentials.json decrypted.txt -p <SECRET_KEY>` - this command would decrypt content of `mozilla_credentials.json` and save it in the `decrypted.txt` file

#### Options
```
  -p, --password <string>   password is required
  -h, --help                display help for command
```
### API

#### Setup

##### First way (recommended)
- require `cryptor` into your script from `./private/cryptor/dist`
    ```
    const cryptor = require('./private/cryptor/dist');
    ```
##### Second way
- Copy `cryptor.js` in your codebase where you are supposed to use it.

- Install as dependency [crypto-js](https://github.com/brix/crypto-js)
    ```
    yarn add -D crypto-js
    ```
- require cryptor into your script
    ```
    const cryptor = require('./cryptor.js');
    ```
#### Code example

```
// Encrypt file
await cryptor(password).encryptFile(input, output);

// Decrypt file
await cryptor(password).decryptFile(input, output);

// Get decrypted content
const decryptedContent = await cryptor(password).getDecryptedContent(input);
```
