const fs = require('fs').promises;
const CryptoJS = require('crypto-js');

const cryptor = (password) => {
    if (!password) {
        throw new Error('Password is required');
    }

    const encrypt = (content) => {
        const encrypted = CryptoJS.AES.encrypt(content, password);
        return encrypted.toString();
    };

    const decrypt = (encryptedContent) => {
        const decrypted = CryptoJS.AES.decrypt(encryptedContent, password);
        return decrypted.toString(CryptoJS.enc.Utf8);
    };

    const encryptFile = async (input, output = input) => {
        if (!input) {
            throw new Error('Input is required');
        }
        const contentToEncrypt = await fs.readFile(input, 'utf8');
        const encryptedContent = encrypt(contentToEncrypt);
        await fs.writeFile(output, encryptedContent);
    };

    const getDecryptedContent = async (input) => {
        if (!input) {
            throw new Error('Input is required');
        }

        const contentToDecrypt = await fs.readFile(input, 'utf8');

        let decryptedContent;
        try {
            decryptedContent = decrypt(contentToDecrypt);
        } catch (e) {
            console.log(e);
        }

        if (contentToDecrypt.length > 0 && !decryptedContent) {
            throw new Error('Seems like your password is wrong, or your are trying to decrypt non encrypted file');
        }

        return decryptedContent;
    };

    const decryptFile = async (input, output = input) => {
        if (!input) {
            throw new Error('Input is required');
        }

        const decryptedContent = await getDecryptedContent(input);

        await fs.writeFile(output, decryptedContent);
    };

    return {
        getDecryptedContent,
        encryptFile,
        decryptFile,
    };
};

module.exports = cryptor;
