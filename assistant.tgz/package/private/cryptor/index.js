const cryptor = require('./cryptor');

module.exports = cryptor;
