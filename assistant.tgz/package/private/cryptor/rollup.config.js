const resolve = require('@rollup/plugin-node-resolve');
const commonjs = require('@rollup/plugin-commonjs');

export default [
    {
        input: 'index.js',
        output: {
            file: 'dist/index.js',
            format: 'cjs'
        },
        external: [ 'fs', 'crypto' ],
        plugins: [
            resolve(),
            commonjs(),
        ]
    }
];
